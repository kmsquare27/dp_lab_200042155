﻿namespace Lab_05
{
    public interface INotification
    {
        void SendNotification(string p1);
    }
}
