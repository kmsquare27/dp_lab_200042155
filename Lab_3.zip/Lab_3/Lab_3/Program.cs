﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;

namespace Lab_3
{
    public class Program
    {
        static void Main(string[] args)
        {
            IBeverage beverage = new Whipped_Cream(new White_Sugar(new Milk(new Espresso(new Nothing()))));
            Console.WriteLine($"Beverage: {beverage.description("")}, Price: {beverage.price(0):C}");
            Console.ReadLine();
        }
    }
}

    public interface IBeverage
    {
        float price(float cost);                
        string description(string describe);    
    }
    public class Nothing : IBeverage
    {
        public float price(float price)
        {
            return price; 
        }

        public string description(string describe)
        {
            return describe; 
        }
    }

    public class Espresso : IBeverage
    {
        IBeverage NextBeverage;

        public Espresso(IBeverage nextBeverage)
        {
            NextBeverage = nextBeverage;
        }

        public float price(float price)
        {
            price += 3f; 
            return NextBeverage.price(price); 
        }

        public string description(string describe)
        {
            describe += "Espresso with ";
            return NextBeverage.description(describe);
        }
    }

    public class Latte : IBeverage
    {
        IBeverage NextBeverage;

        public Latte(IBeverage nextBeverage)
        {
            NextBeverage = nextBeverage;
        }

        public float price(float price)
        {
            price += 4f; 
            return NextBeverage.price(price);
        }

        public string description(string describe)
        {
            describe += "Latte with ";
            return NextBeverage.description(describe);
        }
    }

    public class Cappuccino : IBeverage
    {
        IBeverage NextBeverage;

        public Cappuccino(IBeverage nextBeverage)
        {
            NextBeverage = nextBeverage;
        }

        public float price(float price)
        {
            price += 3.5f; 
            return NextBeverage.price(price);
        }

        public string description(string describe)
        {
            describe += "Cappuccino with ";
            return NextBeverage.description(describe);
        }
    }

    public class Milk : IBeverage
    {
        IBeverage NextBeverage;

        public Milk(IBeverage nextBeverage)
        {
            NextBeverage = nextBeverage;
        }

        public float price(float price)
        {
            price += 0.5f; 
            return NextBeverage.price(price);
        }

        public string description(string describe)
        {
            describe += "Milk ";
            return NextBeverage.description(describe);
        }
    }

    public class White_Sugar : IBeverage
    {
        IBeverage NextBeverage;

        public White_Sugar(IBeverage nextBeverage)
        {
            NextBeverage = nextBeverage;
        }

        public float price(float price)
        {
            price += 0.3f; 
            return NextBeverage.price(price);
        }

        public string description(string describe)
        {
            describe += "White Sugar ";
            return NextBeverage.description(describe);
        }
    }

    public class Whipped_Cream : IBeverage
    {
        IBeverage NextBeverage;

        public Whipped_Cream(IBeverage nextBeverage)
        {
            NextBeverage = nextBeverage;
        }

        public float price(float price)
        {
            price += 0.7f; 
            return NextBeverage.price(price);
        }

        public string description(string describe)
        {
            describe += "Whipped Cream ";
            return NextBeverage.description(describe);
        }
    }
