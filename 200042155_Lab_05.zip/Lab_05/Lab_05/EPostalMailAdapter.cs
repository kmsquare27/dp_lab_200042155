﻿namespace Lab_05
{
    public class EPostalMailAdapter : INotification
    {
        PostalMailService postal_mail;
        public EPostalMailAdapter (PostalMailService postal_mail )
        {
            this.postal_mail = postal_mail;
        }
        public void SendNotification(string p1 )
        {
            var info = postal_mail.GetInfo();
            postal_mail.SendPostalMail(p1,info.Item1,info.Item2);
        }
    }
}
