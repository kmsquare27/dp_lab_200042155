﻿namespace Lab_05
{
    public class SMSNotification : INotification
    {
        public void SendNotification()
        {

        }
    }
}
