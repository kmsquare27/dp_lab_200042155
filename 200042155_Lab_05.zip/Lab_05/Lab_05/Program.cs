﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab_05
{
    class Program
    {
        static void Main(string[] args)
        {

            var email = new EmailNotification();
            email.SendNotification();

            var postal_mail = new EPostalMailAdapter(new PostalMailService());

            Console.ReadLine();
        }
    }
}
