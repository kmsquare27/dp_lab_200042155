using System;
using System.Collections.Generic;

public enum RideType
{
    Carpool,
    LuxuryRide,
    BikeRide
}

public enum NotificationType
{
    SMS,
    Email,
    InApp
}

public interface INotificationService
{
    void SendNotification(string message, NotificationType type);
}

public class SmsNotificationService : INotificationService
{
    public void SendNotification(string message, NotificationType type)
    {
        Console.WriteLine($"Sending SMS: {message}");
    }
}

public class EmailNotificationService : INotificationService
{
    public void SendNotification(string message, NotificationType type)
    {
        Console.WriteLine($"Sending Email: {message}");
    }
}

public class InAppNotificationService : INotificationService
{
    public void SendNotification(string message, NotificationType type)
    {
        Console.WriteLine($"Sending Email: {message}");
    }
}

public interface IPaymentMethod
{
    void ProcessPayment(decimal amount);
}

public class CreditCard : IPaymentMethod
{
    public void ProcessPayment(decimal amount)
    {
        Console.WriteLine($"Processing credit card payment of {amount:C}");
    }
}

public class PayPal : IPaymentMethod
{
    public void ProcessPayment(decimal amount)
    {
        Console.WriteLine($"Processing PayPal payment of {amount:C}");
    }
}

public class digital_wallet : IPaymentMethod
{
    public void ProcessPayment(decimal amount)
    {
        Console.WriteLine($"Processing Digital_Wallet payment of {amount:C}");
    }
}

public class Rider
{
    public int Id { get; set; }
    public string Name { get; set; }
    public string Location { get; set; }
    public float Rating { get; set; }
    public IPaymentMethod PreferredPaymentMethod { get; set; }
    public NotificationType PreferredNotificationType { get; set; }

    public Rider(int id, string name, string location, IPaymentMethod paymentMethod, NotificationType notificationType)
    {
        Id = id;
        Name = name;
        Location = location;
        PreferredPaymentMethod = paymentMethod;
        PreferredNotificationType = notificationType;
    }

    public void RequestRide(string pickup, string dropOff, RideType rideType)
    {
    }

    public void RateDriver(Driver driver, float rating)
    {
    }
}

public class Driver
{
    public int Id { get; set; }
    public string Name { get; set; }
    public string VehicleType { get; set; }
    public string Location { get; set; }
    public float Rating { get; set; }
    public bool IsAvailable { get; set; }

    public Driver(int id, string name, string vehicleType, string location, float rating)
    {
        Id = id;
        Name = name;
        VehicleType = vehicleType;
        Location = location;
        Rating = rating;
        IsAvailable = true;
    }

    public void AcceptRide(Trip trip)
    {
        if (IsAvailable)
        {
            IsAvailable = false;
            trip.AssignDriver(this);
            Console.WriteLine($"{Name} has accepted the ride.");
        }
        else
        {
            Console.WriteLine($"{Name} is not available.");
        }
    }

    public void RateRider(Rider rider, float rating)
    {
    }

    public void UpdateLocation(string newLocation)
    {
        Location = newLocation;
        Console.WriteLine($"{Name} updated location to {Location}");
    }
}

public class Trip
{
    public int Id { get; set; }
    public string PickupLocation { get; set; }
    public string DropOffLocation { get; set; }
    public RideType RideType { get; set; }
    public decimal Fare { get; set; }
    public string Status { get; set; }
    public Driver AssignedDriver { get; set; }
    public Rider RequestingRider { get; set; }

    public Trip(Rider rider, string pickup, string dropOff, RideType rideType)
    {
        RequestingRider = rider;
        PickupLocation = pickup;
        DropOffLocation = dropOff;
        RideType = rideType;
        Status = "Waiting";
    }

    public void AssignDriver(Driver driver)
    {

    }

    public void StartTrip()
    {
        Status = "In Progress";
        Console.WriteLine("Trip has started.");
    }

    public void CompleteTrip()
    {
        Status = "Completed";
        CalculateFare();
        Console.WriteLine("Trip is completed.");
    }

    public void CalculateFare()
    {

    }
}

public class Admin
{
    public int Id { get; set; }
    public string Name { get; set; }
    public string Role { get; set; }
    public Admin(int id, string name, string role)
    {
        Id = id;
        Name = name;
        Role = role;
    }

    public void ManageDriver(Driver driver)
    {

    }

    public void ManageRider(Rider rider)
    {

    }

    public void HandleDispute(Trip trip)
    {

    }
    
    public void ViewTripHistory(Trip trip)
    {

    }
}
