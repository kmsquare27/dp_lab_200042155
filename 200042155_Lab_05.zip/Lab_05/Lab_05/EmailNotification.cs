﻿namespace Lab_05
{
    public class EmailNotification : INotification
    {
        public void SendNotification()
        {

        }
    }
}
