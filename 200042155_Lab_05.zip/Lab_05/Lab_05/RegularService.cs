﻿namespace Lab_05
{
    public class RegularService
    {
        INotification regular_notify;
        public RegularService (  INotification regular_notify )
        {
            this.regular_notify = regular_notify;
        }

        public void SendNotification()
        {
            regular_notify.SendNotification();
        }
    }
}
