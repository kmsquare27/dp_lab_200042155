﻿namespace Lab_05
{
    public class PostalMailService
    {
        public (string, string) GetInfo()
        {
            return ("temporary", "permamnet");
        }
        public void SendPostalMail(string p1, string p2, string p3)
        {

        }
    }
}
